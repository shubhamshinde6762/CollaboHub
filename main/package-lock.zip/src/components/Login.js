import React, { useEffect, useState } from "react";
import LoginDiv from "./LoginComponents/LoginDiv";
import SignUp from "./LoginComponents/SignUp";
import { useNavigate } from "react-router-dom";

const Login = ({ setUser, user, socket }) => {
  const navigate = useNavigate();
  useEffect(() => {
    if (user) {
      navigate(`/dashboard/${user.data.username}`);
    }
  });
  const [isLogin, setLogin] = useState(true);

  return (
    <div className=" bg-slate-950 w-full min-h-screen">
      <container>
        {/* Inner Div */}
        {isLogin ? (
          <LoginDiv setUser={setUser} socket={socket} setLogin={setLogin} />
        ) : (
          <SignUp setUser={setUser} socket={socket} setLogin={setLogin} />
        )}
      </container>
    </div>
  );
};

export default Login;
