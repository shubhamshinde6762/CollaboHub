import React from 'react'

const PieChart = () => {
  return (
    <div>
        PieChart
    </div>
  )
}

export default PieChart