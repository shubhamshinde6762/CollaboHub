import React from "react";
// import Bar from "../Bar";
import BusyChart from "../BusyChart";

const userPanel = ({ user, allDetails, busyArray }) => {
  return (
    <div className="min-w-[260px] shadeEffect flex bg-[#fcf8ff] flex-col p-3 w-[95%] mx-[2.5%] rounded-lg justify-center ">
      <div className="flex gap-6 ">
        <img src={user.data.profilePhoto} className="rounded-full w-[30%] " />
        <div className="flex flex-col justify-center">
          <div className="font-bold font-poppins text-3xl">
            {user.data.username}
          </div>
          <div>{user.data.email}</div>
        </div>
      </div>

      <div className="w-full h-full">
        <BusyChart busyArray={busyArray} />
      </div>
    </div>
  );
};

export default userPanel;
