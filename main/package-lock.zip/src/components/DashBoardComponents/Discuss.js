import React, { useEffect, useState } from "react";
import Chat from "./DiscussSection/Chat";
import ChatPeopleSection from "./DiscussSection/ChatPeopleSection";
import toast from "react-hot-toast";
import { Toaster } from "react-hot-toast";

const Discuss = ({ user, socket, updateUser, newMessage, needToUpdateChat, setNewMessage, updateChat, chat, setChatSection }) => {
  // const [chat, setChatSection] = useState();
  

  // useEffect(() => {
  //   const handleNewPersonalChat = (data) => {
  //     console.log("dataNew", chat);
  //     setChatSection((prevChat) => {
  //       if (
  //         prevChat &&
  //         !prevChat._id &&
  //         prevChat.user &&
  //         prevChat.user._id === data.person2._id
  //       ) {
  //         let newChat = data.chat;
  //         newChat["user"] = prevChat.user;
  //         return newChat;
  //       }
  //       return prevChat;
  //     });
  //     updateChat((prev) => !prev);
  //   };

  //   const handleMessageReceived = (data) => {
  //     let res = data;
  //     // console.log("daaaaaaata", res.newMessage.sender._id, user);
  //     setNewMessage(res);
  //     if (
  //       res.newMessage.sender._id 
  //     )
  //       toast((t) => (
  //         <div className="">
  //           <div className="flex gap-2 font-bold font-poppins items-center">
  //             <img
  //               className="rounded-full w-11"
  //               src={res.newMessage.sender.profilePhoto}
  //             />
  //             <p className="flex flex-col">
  //               <p>{res.newMessage.sender.username}</p>
  //               <p className=" text-[0.8rem ] font-poppins">
  //                 {res.newMessage.sender.email}
  //               </p>
  //             </p>
  //           </div>
  //           <div className="font-poppins text-center w-full">
  //             <p>{res.newMessage.content}</p>
  //           </div>
  //         </div>
  //       ));
  //   };

  //   try {
  //     socket.on("newPersonalChat", handleNewPersonalChat);
  //     socket.on("messageReceived", handleMessageReceived);
  //   } catch (error) {
  //     console.error("Error setting up socket:", error);
  //   }

  //   return () => {
  //     try {
  //       socket.off("newPersonalChat", handleNewPersonalChat);
  //       socket.off("messageReceived", handleMessageReceived);
  //     } catch (error) {
  //       console.error("Error disconnecting socket:", error);
  //     }
  //   };
  // }, []);

  return (
    <div className="text-white h-[89vh] w-full m-3 flex gap-x-2">
      <ChatPeopleSection
        needToUpdateChat={needToUpdateChat}
        newMessage={newMessage}
        setChatSection={setChatSection}
        user={user}
        className=""
      />
      <Chat newMessage={newMessage} chat={chat} user={user}></Chat>
    </div>
  );
};

export default Discuss;
