import React, { useEffect } from "react";
import { useState } from "react";
import { FaArrowRight } from "react-icons/fa";
import { MdVisibility } from "react-icons/md";
import { MdVisibilityOff } from "react-icons/md";
import { IoMdCheckboxOutline } from "react-icons/io";
import { MdOutlineCheckBoxOutlineBlank } from "react-icons/md";
import { CiLogin } from "react-icons/ci";
import axios from 'axios';
import { useNavigate } from "react-router-dom";


const LoginDiv = ({setUser, setLogin, socket}) => {

  const [message, setMessage] = useState("");

  const navigate = useNavigate();


  const fetchData = async () => {
    try {
      const response = await axios.post('http://localhost:5000/api/v1/login', formdata);
  
      // Check if the response status is successful (e.g., 200)
      if (response.status === 200) {
        localStorage.setItem("token", response.data.data.token);
        setUser(response.data);
        // console.log(response.data);
        socket.emit("login", {
          userId: response.data.data._id,
          socketId: socket.id,
        });
        navigate(`/dashboard/${response.data.data.username}`);
      } else {
        // Handle non-successful status codes
        setMessage("*Internal Error");
        setUser("")
      }
    } catch (error) {
      const {response} = error
      console.error('Error making the POST request:', response);

      if (response.status === 401)
      {
        if (response.data.error === "401-USER")
          setMessage("*User Not Exists")
        else  if (response.data.error === "401-PASSWORD")
          setMessage("*Password is Incorrect")
      }
      else
        setMessage("*Internal Error")

    }
  };

  const loginHandler = async(event)=>
  {
    event.preventDefault();
    //console.log(formdata);
    if ( formdata["identity"] === "" || formdata["password"] === ""){
      return 
    } 
    
    try{
      await fetchData();
      
    }
    catch(err)
    {
      console.log(err);
    }
    
  }


  const visibilityHandler = (event)=>{
    setShowPassWord(!showPassword)
  }

  const [showPassword,setShowPassWord] = useState(false);
  const [formdata,setFormdata] = useState({
    identity:"",
    password:"",
    rememberMe:false
  })

  const changeHandler = (event) => {
    const {value, id, type, checked, name} = event.target;
    setFormdata((state) => {
      return{
        ...state, 
          [name]: type === "checkbox"? checked: value
        
      }
    })
    setMessage("");
    console.log(formdata);
  }

  const validateData = ()=> {
    if (formdata.password)
      if (formdata.password[0] === " " || formdata.password.split(" ").length > 1)
        setMessage("*Password should not contains Spaces")
  }

  useEffect(() => {
    validateData();
  }, [formdata]);

    return (
    <div className="flex items-center justify-center w-full m-x-5 select-none cursor-default">
      {/* Image Section */}

      <div className="p-16 m-2 grid md:grid-cols-1 gap-11 lg:grid-cols-2">
        <div className="text-white group m-2 min-w-[27rem] rounded-3xl flex flex-col hover:shadow-white transition-all duration-200 shadow-gray-400 shadow">
          <div className="flex flex-col m-10">
            <p className="text-5xl font-roboto-slab leading-relaxed">
              Welcome to <br />{" "}
              <span className="text-6xl transition-all duration-300 font-poppins text-sky-400 group-hover:text-red-500">CollaboHub!</span>
            </p>
            <br />
            <p className="text-3xl font-exo leading-13 text-gray-400">
              Immerse yourself in a collaborative work environment that empowers
              your team and enhances project management.
            </p>
          </div>

          <div className="flex items-center justify-center m-4 ">
            <button
              onClick={() => setLogin(false)}
              className="flex hover:shadow-inner group animate-bounce hover:animate-none  hover:shadow-slate-600 transition-all duration-500 font-roboto-slab text-xl items-center justify-center rounded-e-3xl rounded-t-3xl p-4 space-x-2 border border-lime-600 "
            >
              <p>Get Started</p>
              <FaArrowRight className="animate-pulse text-red-500 group-hover:text-purple-500 group-hover:scale-105 group-hover:border-indigo-500" />
            </button>
          </div>
        </div>

        {/* <div className='px-10'> */}
        <div className=" text-white m-2 p-10 group flex flex-col items-center rounded-3xl  hover:shadow-white transition-all duration-200 shadow-gray-400 shadow-inner">
          <div className="text-4xl font-poppins group-hover:scale-125 group-hover:text-sky-400 group-hover:animate-pulse transitiom-all duration-1000 text-bold text-center w-full">Login</div>

          <div className="flex flex-col items-center mt-9 w-full h-full">
            <form className="flex h-full flex-col items-center justify-center w-full space-y-3">
              <label className="w-full px-10">
                <p className="py-1 text-xl font-poppins">Email Address/Username<sup className="text-orange-400">*</sup></p>
                <input
                  onChange={changeHandler}
                  className=" font-poppins text-2xl w-full px-3 py-2 placeholder:bg-gray-950 outline-0 shadow hover:shadow-sky-400 focus:shadow-sky-400 bg-gray-950 rounded-lg  "
                  type="text"
                  value={formdata["identity"]}
                  placeholder="Email Address/Username"
                  name="identity"
                >

              </input>
              </label>
              <label className="w-full px-10" >
              <p className="py-1 font-poppins text-xl">Password<sup className="text-orange-400">*</sup></p>
              <div className="relative">
                <input
                  onChange={changeHandler}
                  className=" font-poppins px-3 pr-14 py-2  w-full text-2xl placeholder:bg-gray-950 outline-0 shadow hover:shadow-sky-400 focus:shadow-sky-400 bg-gray-950 rounded-lg  "
                  type={showPassword? "text":"password"}
                  value={formdata["password"]}
                  placeholder="Password"
                  name="password"
                >

                </input>
                <span onClick={visibilityHandler} className="absolute top-4 right-5">
                {
                  showPassword? (<MdVisibilityOff/>):(<MdVisibility/>)
                }
                </span>
              </div>
              </label>
              <div className="w-full mb-10">
                <label htmlFor="remId" className="w-full relative px-10 flex">
                  <input   onChange={changeHandler} id="remId" type="checkbox" value={formdata["rememberMe"]} className="absolute bottom-[0.2rem] hidden" name="rememberMe"/>
                  <div className="flex space-x-1 items-center text-md  text-sky-400">
                    {formdata["rememberMe"]? (<IoMdCheckboxOutline/>):(<MdOutlineCheckBoxOutlineBlank/>)}
                    <p>Remember Me</p>
                  </div>                
                </label>
                <span className="italic-text px-10 text-pink-500">{message}</span>
                
              </div>
              <button onClick={loginHandler} className="loginButton px-5 py-2 flex items-center font-poppins text-xl rounded-xl hover:scale-110 transition-all">LogIn <CiLogin/></button>
            </form>
          </div>
        </div>
        {/* </div> */}
      </div>
    </div>
  );
};

export default LoginDiv;
