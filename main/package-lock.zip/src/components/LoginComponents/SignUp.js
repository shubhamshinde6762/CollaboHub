import React from "react";
import { useState, useEffect } from "react";
import { FaArrowRight } from "react-icons/fa";
import { MdVisibility } from "react-icons/md";
import { MdVisibilityOff } from "react-icons/md";
import { IoMdCheckboxOutline } from "react-icons/io";
import { MdOutlineCheckBoxOutlineBlank } from "react-icons/md";
import { CiLogin } from "react-icons/ci";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import io from "socket.io-client";
const socket = io("http://localhost:5000");



const SignUp = ({setLogin, setUser, socket}) => {
  const [message,setMessage] = useState("");
  const navigate = useNavigate();
  const fetchData = async() => {
  try{
    const response = await axios.post('http://localhost:5000/api/v1/signUp', formdata)

    if (response.status === 200) {
      localStorage.setItem("token", response.data.data.token);
      setUser(response.data);
      // console.log(response.data);
      socket.emit("login", {
        userId: response.data.data._id,
        socketId: socket.id,
      });
      navigate(`/dashboard/${response.data.data.username}`);
    } else {
      // Handle non-successful status codes
      setMessage("*Internal Error")
      setUser("")
    }
  } catch (error) {
    const {response} = error
    console.error('Error making the POST request:', response);

    if (response.status === 400)
    {
      if (response.data.error === "400-EMAIL")
        setMessage("*Account Already Exists with this Email ID")
      else  if (response.data.error === "400-USERNAME")
        setMessage("*Username not Available")
    }
    else
      setMessage("*Internal Error")

    }

    // const output = await response.json();
    //console.log(response)

  }

  const loginHandler = async(event)=>
  {
    event.preventDefault();
    //console.log(formdata);
    if ( formdata["email"] === "" || formdata["password"] === "" || formdata["name"] === "" || 
    formdata["confirmPassword"] !== formdata["password"] || formdata["username"] === ""){
      setMessage("*Required Feilds")
      return 
    } 
    
    try{
      await fetchData();
      // navigate("/")
    }
    catch(err)
    {
      //console.log(err);
    }
    
  }


  const visibilityHandler = (name)=>{
    setShowPassWord(state =>{
      return {
        ...state, [name]: !showPassword[name]
      };
    })

    //console.log(showPassword)
  }

  const [showPassword,setShowPassWord] = useState({"visible1":false, "visible2":false});
  const [formdata,setFormdata] = useState({
    name:"",
    email:"",
    password:'',
    confirmPassword:"",
    rememberMe:false,
    username:""

  })

  const validateData = ()=> {
    if (formdata.password.length !== 0 && formdata.confirmPassword.length !== 0 && formdata.confirmPassword !== formdata.password)
      setMessage("*Password not Matches")


    if (formdata.password)
      if (formdata.password[0] === " " || formdata.password.split(" ").length > 1)
        setMessage("*Password should not contains Spaces")
      else if (formdata.password.length < 8)
        setMessage("*Password should have minimum 8 characters")

      
  }

  useEffect(() => {
    validateData();
  }, [formdata]);

  const changeHandler = (event) => {
    const {value, id, type, checked, name} = event.target;
    setFormdata((state) => {
      return{
        ...state, 
          [name]: type === "checkbox"? checked: value
        
      }
    })

    setMessage("");


    console.log(formdata);
  }

    return (
    <div className="flex items-center justify-center w-full m-x-5 select-none cursor-default">
      {/* Image Section */}

      <div className="p-16 m-2 grid md:grid-cols-1 gap-11 lg:grid-cols-2">
        <div  className="lg:order-2 md:order-1 flex items-start">
          <div className="text-white group m-2 min-w-[27rem] rounded-3xl flex flex-col hover:shadow-white transition-all duration-200 shadow-gray-400 shadow">
            <div className="flex flex-col m-10">
              <p className="text-5xl font-roboto-slab leading-relaxed">
                Welcome to <br />{" "}
                <span className="text-6xl transition-all duration-300 font-poppins text-sky-400 group-hover:text-red-500">CollaboHub!</span>
              </p>
              <br />
              <p className="text-3xl font-exo leading-13 text-gray-400">
              Collaborate, Innovate, let your talents combine,
              Hit signup now, where your brilliance will shine!
              </p>
            </div>

            <div className="flex items-center justify-center m-4 ">
              <button
                onClick={() => setLogin(true)}
                className="flex hover:shadow-inner group animate-bounce hover:animate-none  hover:shadow-slate-600 transition-all duration-500 font-roboto-slab text-xl items-center justify-center rounded-e-3xl rounded-t-3xl p-4 space-x-2 border border-lime-600 "
              >
                <p>Login</p>
                <FaArrowRight className="animate-pulse text-red-500 group-hover:text-purple-500 group-hover:scale-105 group-hover:border-indigo-500" />
              </button>
            </div>
          </div>
        </div>

        {/* <div className='px-10'> */}
        <div className=" text-white lg:order-1 md:order-2 m-2 p-10 group flex flex-col items-center rounded-3xl  hover:shadow-white transition-all duration-200 shadow-gray-400 shadow-inner">
          <div className="text-4xl font-poppins group-hover:scale-125 group-hover:text-sky-400 group-hover:animate-pulse transitiom-all duration-1000 text-bold text-center w-full">SignUp</div>

          <div className="flex flex-col items-center mt-9 w-full h-full">
            <form className="flex h-full flex-col items-center justify-center w-full space-y-3">
              <label className="w-full px-10">
                <p className="py-1 text-xl font-poppins">Name<sup className="text-orange-400">*</sup></p>
                <input
                  onChange={changeHandler}
                  className=" font-poppins text-2xl w-full px-3 py-2 placeholder:bg-gray-950 outline-0 shadow hover:shadow-sky-400 focus:shadow-sky-400 bg-gray-950 rounded-lg  "
                  type="text"
                  value={formdata["name"]}
                  placeholder="Name"
                  name="name"
                >

                </input>
              </label>
              <label className="w-full px-10">
                <p className="py-1 text-xl font-poppins">Email Address<sup className="text-orange-400">*</sup></p>
                <input
                  onChange={changeHandler}
                  className=" font-poppins text-2xl w-full px-3 py-2 placeholder:bg-gray-950 outline-0 shadow hover:shadow-sky-400 focus:shadow-sky-400 bg-gray-950 rounded-lg  "
                  type="email"
                   value={formdata["email"]}
                  placeholder="Email Address"
                  name="email"
                >

                </input>
              </label>
              <label className="w-full px-10">
                <p className="py-1 text-xl font-poppins">Username<sup className="text-orange-400">*</sup></p>
                <input
                  onChange={changeHandler}
                  className=" font-poppins text-2xl w-full px-3 py-2 placeholder:bg-gray-950 outline-0 shadow hover:shadow-sky-400 focus:shadow-sky-400 bg-gray-950 rounded-lg  "
                  type="text"
                  value={formdata["username"]}
                  placeholder="Username"
                  name="username"
                >

                </input>
              </label>
              <label className="w-full px-10" >
              <p className="py-1 font-poppins text-xl">Password<sup className="text-orange-400">*</sup></p>
              <div className="relative">
                <input
                  onChange={changeHandler}
                  className=" font-poppins px-3 py-2 pr-14  w-full text-2xl placeholder:bg-gray-950 outline-0 shadow hover:shadow-sky-400 focus:shadow-sky-400 bg-gray-950 rounded-lg  "
                  type={showPassword["visible1"]? "text":"password"}
                  value={formdata["password"]}
                  placeholder="Password"
                  name="password"
                >

                </input>
                <span id="visible1" onClick={() => visibilityHandler("visible1")} className="absolute top-4 right-5">
                {
                  showPassword["visible1"]? (<MdVisibilityOff/>):(<MdVisibility/>)
                }
                </span>
              </div>
              </label>
              <label className="w-full px-10" >
              <p className="py-1 font-poppins text-xl">Confirm Password<sup className="text-orange-400">*</sup></p>
              <div className="relative">
                <input
                  onChange={changeHandler}
                  className=" font-poppins px-3 py-2 pr-14  w-full text-2xl placeholder:bg-gray-950 outline-0 shadow hover:shadow-sky-400 focus:shadow-sky-400 bg-gray-950 rounded-lg  "
                  type={showPassword["visible2"]? "text":"password"}
                  value={formdata["confirmPassword"]}
                  placeholder="Confirm Password"
                  name="confirmPassword"
                >

                </input>
                <span id="visible2"  onClick={() => visibilityHandler("visible2")} className="absolute top-4 right-5">
                {
                  showPassword["visible2"]? (<MdVisibilityOff/>):(<MdVisibility/>)
                }
                </span>
              </div>
              </label>
              <div className=" px-10 w-full">
                <label htmlFor="remId" className="w-full relative flex">
                  <input   onChange={changeHandler} id="remId" type="checkbox" value={formdata["rememberMe"]} className="absolute bottom-[0.2rem] hidden" name="rememberMe"/>
                  <div className="flex space-x-1 items-center text-md text-sky-400">
                    {formdata["rememberMe"]? (<IoMdCheckboxOutline/>):(<MdOutlineCheckBoxOutlineBlank/>)}
                    <p>Remember Me</p>
                  </div>
                </label>
                <span className=" italic-text mb-10 text-pink-500">{message}</span>
                
              </div>
              <button onClick={loginHandler} className="loginButton px-5 py-2 flex items-center font-poppins text-xl rounded-xl hover:scale-110 transition-all">SignUp <CiLogin/></button>
            </form>
          </div>
        </div>
        {/* </div> */}
      </div>
    </div>
  );
};

export default SignUp;
