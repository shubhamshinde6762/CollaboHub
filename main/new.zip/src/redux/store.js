import { configureStore } from "@reduxjs/toolkit";


export const store = configureStore(
{
        reducer : {
            null:null
        }
}
);

export default store;